//
//  User.h
//  AzureB2CDemo
//
//  Created by lino on 11/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject

@property BOOL accountEnabled;
@property (strong) NSArray* alternativeSignInNamesInfo;
@property (strong) NSString* creationType;
@property (strong) NSString* displayName;
@property (strong) NSString* mailNickname;
@property (strong) NSDictionary* passwordProfile;
@property (strong) NSString* passwordPolicies;

- (id)initWithEmail:(NSString *)email andPassword:(NSString *)password;
- (NSDictionary *)toDictionary;

@end
