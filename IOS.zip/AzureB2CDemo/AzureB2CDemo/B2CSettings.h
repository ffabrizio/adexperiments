//
//  B2CSettings.h
//  AzureB2CDemo
//
//  Created by lino on 10/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface B2CSettings : NSObject

@property (strong) NSString* authority;
@property (strong) NSString* clientId;
@property (strong) NSString* redirectUri;
@property (strong) NSString* signInPolicy;
@property (strong) NSString* signUpPolicy;
@property BOOL fullScreen;
@property BOOL showClaims;
@property NSMutableArray* scopes;

- (id)initWithData:(NSDictionary *)data;

@end
