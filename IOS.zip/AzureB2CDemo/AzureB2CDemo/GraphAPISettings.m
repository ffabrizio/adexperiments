//
//  GraphAPISettings.m
//  AzureB2CDemo
//
//  Created by lino on 10/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import "GraphAPISettings.h"

@implementation GraphAPISettings

- (id)initWithData:(NSDictionary *)data {
    self = [super init];
    if(self) {
        self.clientSecret = [data objectForKey:@"client_secret"];
        self.grantType = [data objectForKey:@"grant_type"];
        self.clientId = [data objectForKey:@"client_id"];
        self.resource = [data objectForKey:@"resource"];
        self.tokenUrl = [data objectForKey:@"token_url"];
        self.userEndpoint = [data objectForKey:@"user_endpoint"];
    }
    return self;
}

@end
