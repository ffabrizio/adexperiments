//
//  ViewController.m
//  AzureB2CDemo
//
//  Created by lino on 10/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import "ViewController.h"
#import "ApplicationSettingsData.h"
#import "ProtectedViewController.h"
#import "CustomSignUpViewController.h"
#import "CustomSignInViewController.h"
#import "Utilities.h"
#import "ADALiOS/ADAuthenticationContext.h"
#import "ADALiOS/ADAuthenticationSettings.h"

@interface ViewController ()
@property (strong) ApplicationSettingsData *data;
@property (strong) NSString *token;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *customSignUpLoading;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.data = [ApplicationSettingsData getInstance];
}

- (void)graphAPIGetTokenWithCompletionBlock:(void (^) (NSString* token)) completionBlock
{
    NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:[[NSURL alloc] initWithString:self.data.graphAPISettings.tokenUrl]];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPMethod:@"POST"];
    
    NSString __strong *body = [NSString stringWithFormat:@"resource=%@&client_id=%@&client_secret=%@&grant_type=%@",
                      [Utilities urlEncode:self.data.graphAPISettings.resource],
                      [Utilities urlEncode:self.data.graphAPISettings.clientId],
                      [Utilities urlEncode:self.data.graphAPISettings.clientSecret],
                      [Utilities urlEncode:self.data.graphAPISettings.grantType]];
    [request setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];
    

    NSURLSessionConfiguration* config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession* session = [NSURLSession sessionWithConfiguration:config];
    NSURLSessionDataTask* dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (!error) {
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
            NSLog(@"Response %@", json);
            completionBlock([json objectForKey:@"access_token"]);
        }
        else{
            completionBlock(nil);
        }
    }];
    [dataTask resume];
}

- (void)processPolicy:(NSString *)policyName {
    
    ADAuthenticationError *error;
    ADAuthenticationContext* authContext = [ADAuthenticationContext authenticationContextWithAuthority:self.data.b2cSettings.authority error:&error];
    NSURL *redirectUri = [[NSURL alloc] initWithString:self.data.b2cSettings.redirectUri];
    
    [ADAuthenticationSettings sharedInstance].enableFullScreen = self.data.b2cSettings.fullScreen;
    [authContext acquireTokenWithScopes:nil
                       additionalScopes:nil
                               clientId:self.data.b2cSettings.clientId
                            redirectUri:redirectUri
                             identifier:[ADUserIdentifier identifierWithId:self.data.userItem.profileInfo.username type:RequiredDisplayableId]
                         promptBehavior:AD_PROMPT_ALWAYS
                   extraQueryParameters: nil
                                 policy: policyName
                        completionBlock:^(ADAuthenticationResult *result){
                            if (result.status != AD_SUCCEEDED){
                                NSLog(@"Error %@", result.error);
                            }
                            else {
                                NSLog(@"Token 1%@", result.tokenCacheStoreItem.accessToken);
                                
                                if(policyName == self.data.b2cSettings.signInPolicy) {
                                    ProtectedViewController *pvc = [self.storyboard instantiateViewControllerWithIdentifier:@"protectedVC"];
                                    pvc.profileInfo = result.tokenCacheStoreItem.profileInfo;
                                    [self presentViewController:pvc animated:YES completion:nil];
                                }
                            }
                        }];
}

- (IBAction)signUpWithPolicy:(UIButton *)sender {
    [self processPolicy:self.data.b2cSettings.signUpPolicy];
}

- (IBAction)signInWithPolicy:(UIButton *)sender {
    [self processPolicy:self.data.b2cSettings.signInPolicy];
}

- (IBAction)customSignUp:(UIButton *)sender {
    [self.customSignUpLoading startAnimating];
    if(!self.token){
        [self graphAPIGetTokenWithCompletionBlock:^(NSString *token) {
            if(token){
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.token = token;
                    [self customSignUp:nil];
                });
            }
        }];
    }
    else {
        if(self.customSignUpLoading.isAnimating){
            [self.customSignUpLoading stopAnimating];
            [self.view setNeedsDisplay];
        }
        CustomSignUpViewController *csuv = [self.storyboard instantiateViewControllerWithIdentifier:@"customSignUpVC"];
        csuv.token = self.token;
        [self presentViewController:csuv animated:YES completion:nil];
    }
}

- (IBAction)customSignIn:(UIButton *)sender {
    CustomSignInViewController *csuv = [self.storyboard instantiateViewControllerWithIdentifier:@"customSignInVC"];
    [self presentViewController:csuv animated:YES completion:nil];
}

@end
