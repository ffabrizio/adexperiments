//
//  CustomSignInViewController.m
//  AzureB2CDemo
//
//  Created by lino on 06/01/2016.
//  Copyright © 2016 uk.co.syzygy. All rights reserved.
//

#import "CustomSignInViewController.h"
#import "Utilities.h"
#import "ApplicationSettingsData.h"
#import "ProtectedViewController.h"

@interface CustomSignInViewController ()
@property (strong) ApplicationSettingsData *data;
@property (weak, nonatomic) IBOutlet UITextField *usernameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextfield;
@property (weak, nonatomic) IBOutlet UILabel *errorLabel;
@end

@implementation CustomSignInViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.data = [ApplicationSettingsData getInstance];
}

- (IBAction)closeAction:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)getSignInTokenWithCompletionBlock:(void (^) (NSString* token)) completionBlock
{
    NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:[[NSURL alloc] initWithString:self.data.graphAPISettings.tokenUrl]];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPMethod:@"POST"];
    
    // username - johnsmith@test.com
    // password - P@ssword!
    
    NSString *emailFix = [self.usernameTextField.text stringByReplacingOccurrencesOfString:@"@" withString:@"_"];
    
    NSString __strong *body = [NSString stringWithFormat:@"username=%@&password=%@&grant_type=%@&client_id=%@&client_secret=%@&scope=%@&resource=%@",
                               [Utilities urlEncode:[NSString stringWithFormat:@"%@#EXT#@ad1908.onmicrosoft.com", emailFix]],
                               [Utilities urlEncode:self.passwordTextfield.text],
                               [Utilities urlEncode:@"password"],
                               [Utilities urlEncode:@"13cafffe-c670-4935-9ee1-3b350296a297"],
                               [Utilities urlEncode:@"NgHm4Aiyi14+I/poJRkgmzeyIOqIp9VdJkrZ55R7Y08="],
                               [Utilities urlEncode:@"openid"],
                               [Utilities urlEncode:@"https://ad1908.onmicrosoft.com/TodoListService"]];
    [request setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    NSURLSessionConfiguration* config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession* session = [NSURLSession sessionWithConfiguration:config];
    NSURLSessionDataTask* dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (!error) {
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
            NSLog(@"Response %@", json);
            completionBlock([json objectForKey:@"access_token"]);
        }
        else{
            completionBlock(nil);
        }
    }];
    [dataTask resume];
}

- (BOOL)isEmailTextfieldValid {
    return [self.usernameTextField.text containsString:@"@"];
}

- (IBAction)loginAction:(UIButton *)sender {
    self.errorLabel.text = @"";
    
    if(self.usernameTextField.text.length == 0) {
        self.errorLabel.text = @"Please enter username";
        return;
    }
    
    if(![self isEmailTextfieldValid]) {
        self.errorLabel.text = @"Invalid username";
        return;
    }
    
    if(self.passwordTextfield.text.length == 0) {
        self.errorLabel.text = @"Please enter password";
        return;
    }
    
    [self getSignInTokenWithCompletionBlock:^(NSString *token) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if(token){
                ProtectedViewController *pvc = [self.storyboard instantiateViewControllerWithIdentifier:@"protectedVC"];
                [self presentViewController:pvc animated:YES completion:nil];
            }
            else {
                self.errorLabel.text = @"Invalid username or password";
            }
        });
    }];
}
@end
