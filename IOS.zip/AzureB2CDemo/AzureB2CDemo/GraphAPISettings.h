//
//  GraphAPISettings.h
//  AzureB2CDemo
//
//  Created by lino on 10/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GraphAPISettings : NSObject

@property (strong) NSString* clientSecret;
@property (strong) NSString* grantType;
@property (strong) NSString* clientId;
@property (strong) NSString* resource;
@property (strong) NSString* tokenUrl;
@property (strong) NSString* userEndpoint;

- (id)initWithData:(NSDictionary *)data;

@end
