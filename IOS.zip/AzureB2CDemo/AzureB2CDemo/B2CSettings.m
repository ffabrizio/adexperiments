//
//  B2CSettings.m
//  AzureB2CDemo
//
//  Created by lino on 10/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import "B2CSettings.h"

@implementation B2CSettings

- (id)initWithData:(NSDictionary *)data {
    self = [super init];
    if(self) {
        self.authority = [data objectForKey:@"authority"];
        self.clientId = [data objectForKey:@"client_id"];
        self.redirectUri = [data objectForKey:@"redirectUri"];
        self.signUpPolicy = [data objectForKey:@"signup_policy"];
        self.signInPolicy = [data objectForKey:@"signin_policy"];
        self.showClaims = [[data objectForKey:@"showClaims"] boolValue];
        self.fullScreen = [[data objectForKey:@"fullScreen"] boolValue];
    }
    return self;
}

@end
