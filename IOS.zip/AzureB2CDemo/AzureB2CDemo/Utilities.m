//
//  Utilities.m
//  AzureB2CDemo
//
//  Created by lino on 11/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import "Utilities.h"

@implementation Utilities

+ (NSString *)urlEncode:(NSString *)stringToEncode
{
    return (__bridge_transfer NSString *)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                                 (__bridge CFStringRef)stringToEncode,
                                                                                 NULL,
                                                                                 CFSTR(":/?#[]@!$&'()*+,;="),
                                                                                kCFStringEncodingUTF8);
}

@end
