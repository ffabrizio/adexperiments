//
//  User.m
//  AzureB2CDemo
//
//  Created by lino on 11/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import "User.h"

@implementation User

- (id)initWithEmail:(NSString *)email andPassword:(NSString *)password {
    if (self = [super init]) {
        self.accountEnabled = YES;
        self.alternativeSignInNamesInfo = @[[[NSDictionary alloc] initWithObjectsAndKeys:@"emailAddress", @"type",
                                           email, @"value",
                                           nil]];
        self.creationType = @"NameCoexistence";
        self.displayName = @"test";
        self.mailNickname = @"test";
        self.passwordProfile = [[NSDictionary alloc] initWithObjectsAndKeys:password, @"password",
                                @NO, @"forceChangePasswordNextLogin",
                                nil];
        self.passwordPolicies = @"DisablePasswordExpiration";
    }
    return self;
}

- (NSDictionary *)toDictionary{
    return [[NSDictionary alloc] initWithObjectsAndKeys:
            @(self.accountEnabled), @"accountEnabled",
            self.alternativeSignInNamesInfo, @"alternativeSignInNamesInfo",
            self.creationType, @"creationType",
            self.displayName, @"displayName",
            self.mailNickname, @"mailNickname",
            self.passwordProfile, @"passwordProfile",
            self.passwordPolicies, @"passwordPolicies",
            nil];
}

@end
