//
//  CustomSignInViewController.h
//  AzureB2CDemo
//
//  Created by lino on 06/01/2016.
//  Copyright © 2016 uk.co.syzygy. All rights reserved.
//

#import "ViewController.h"

@interface CustomSignInViewController : ViewController

@end
