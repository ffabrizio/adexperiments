//
//  CustomSignUpViewController.m
//  AzureB2CDemo
//
//  Created by lino on 11/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import "CustomSignUpViewController.h"
#import "ApplicationSettingsData.h"
#import "User.h"
#import "Utilities.h"

@interface CustomSignUpViewController ()
@property (strong) ApplicationSettingsData *data;
@property (weak, nonatomic) IBOutlet UITextField *emailTextfield;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextfield;
@property (weak, nonatomic) IBOutlet UILabel *errorLabel;
@end

@implementation CustomSignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.data = [ApplicationSettingsData getInstance];
}

- (IBAction)closeAction:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)graphAPIGetCreateUser:(User *)user withCompletionBlock:(void (^)()) completionBlock {
    
    NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:[[NSURL alloc] initWithString:self.data.graphAPISettings.userEndpoint]];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"Bearer %@", self.token] forHTTPHeaderField:@"Authorization"];
    [request setHTTPMethod:@"POST"];
    
    NSData* data = [NSJSONSerialization dataWithJSONObject:[user toDictionary] options:0 error:NULL];
    request.HTTPBody = data;
    
//    NSError *error;
//    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:[user toDictionary]
//                                                       options:NSJSONWritingPrettyPrinted
//                                                         error:&error];
//    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
//    NSLog(@"Playload %@", jsonString);
    
    NSURLSessionConfiguration* config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession* session = [NSURLSession sessionWithConfiguration:config];
    NSURLSessionDataTask* dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        if (!error && (long)[(NSHTTPURLResponse *)response statusCode] == 200) {
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
            NSLog(@"Response %@", json);
        }
        completionBlock();
        
    }];
    [dataTask resume];
}

- (BOOL)isEmailTextfieldValid {
    return [self.emailTextfield.text containsString:@"@"];
}

- (BOOL)isPasswordTextfieldValid {
    NSString* passwordReg = @"(?=^.{8,255}$)((?=.*\\d)(?=.*[A-Z])(?=.*[a-z])|(?=.*\\d)(?=.*[^A-Za-z0-9])(?=.*[a-z])|(?=.*[^A-Za-z0-9])(?=.*[A-Z])(?=.*[a-z])|(?=.*\\d)(?=.*[A-Z])(?=.*[^A-Za-z0-9]))^.*";
    NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", passwordReg];
    return [passwordTest evaluateWithObject:self.passwordTextfield.text];
}

- (IBAction)createAction:(UIButton *)sender {
    self.errorLabel.text = @"";
    
    if(![self isEmailTextfieldValid]) {
        self.errorLabel.text = @"Invalid email";
        return;
    }
    
    if(![self isPasswordTextfieldValid]){
        self.errorLabel.text = @"Invalid password complexity. Password should have at least 1 uppercase letter and a number";
        return;
    }
    
    [self graphAPIGetCreateUser:[[User alloc] initWithEmail:self.emailTextfield.text andPassword:self.passwordTextfield.text] withCompletionBlock:^{
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
}
@end
