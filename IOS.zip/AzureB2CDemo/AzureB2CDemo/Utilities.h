//
//  Utilities.h
//  AzureB2CDemo
//
//  Created by lino on 11/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Utilities : NSObject

+ (NSString *)urlEncode:(NSString *)stringToEncode;

@end
