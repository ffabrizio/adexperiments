//
//  ProtectedViewController.m
//  AzureB2CDemo
//
//  Created by lino on 10/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import "ProtectedViewController.h"

@interface ProtectedViewController ()

@end

@implementation ProtectedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //NSLog(@"%@", [self.profileInfo.allClaims objectForKey:@"name"]);
}

- (IBAction)signOut:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
