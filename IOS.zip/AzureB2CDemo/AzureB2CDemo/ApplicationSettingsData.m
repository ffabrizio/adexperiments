//
//  ApplicationSettingsData.m
//  AzureB2CDemo
//
//  Created by lino on 10/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import "ApplicationSettingsData.h"

@implementation ApplicationSettingsData

+(id) getInstance {
    static ApplicationSettingsData *instance = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
        NSDictionary *dictionary = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"settings" ofType:@"plist"]];
        
        instance.b2cSettings = [[B2CSettings alloc] initWithData:[[NSDictionary alloc] initWithDictionary:[dictionary objectForKey:@"AzureAD_B2C"]]];
        instance.graphAPISettings = [[GraphAPISettings alloc] initWithData:[[NSDictionary alloc] initWithDictionary:[dictionary objectForKey:@"GraphApi"]]];
    });
    
    return instance;
}

@end
