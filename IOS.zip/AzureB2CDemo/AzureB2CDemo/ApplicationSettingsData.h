//
//  ApplicationSettingsData.h
//  AzureB2CDemo
//
//  Created by lino on 10/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ADALiOS/ADAuthenticationResult.h"
#import "B2CSettings.h"
#import "GraphAPISettings.h"

@interface ApplicationSettingsData : NSObject

@property (strong) ADTokenCacheStoreItem *userItem;
@property (strong) B2CSettings *b2cSettings;
@property (strong) GraphAPISettings *graphAPISettings;

+(id) getInstance;

@end
