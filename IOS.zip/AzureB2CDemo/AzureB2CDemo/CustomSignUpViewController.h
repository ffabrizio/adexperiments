//
//  CustomSignUpViewController.h
//  AzureB2CDemo
//
//  Created by lino on 11/12/2015.
//  Copyright © 2015 uk.co.syzygy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomSignUpViewController : UIViewController

@property (strong) NSString* token;

@end
